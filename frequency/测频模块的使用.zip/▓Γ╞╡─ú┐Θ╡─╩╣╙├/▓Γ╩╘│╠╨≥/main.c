#include<reg52.h>
#include<intrins.h>
#include"lcd12864c.h"
sbit CLR=P1^0;			 //����
sbit EN=P1^1;			//	ʹ��
sbit PL=P1^2;			//165��������
sbit SDAT=P1^3;			//165 ���ݶ˿�
sbit SCK=P1^4;			 //165ʱ�Ӷ˿�
unsigned long data1[4]={2949767296,0,123456789,6666};
unsigned char addr[4]={0x80,0x90,0x88,0x98};
void Lcd_Display(unsigned char addr,unsigned long dat);
void delay1s20us(void);
void read_hc165(void);
void FPGA_Init();
void main()
{	
	FPGA_Init();
	lcdinit();
	CLR=1;
	_nop_();
	_nop_();
	_nop_();
	CLR=0;
	EN=1;
	delay1s20us();
	EN=0;
   read_hc165();
   Lcd_Display(0x80,data1[0]);
   Lcd_Display(0x90,data1[1]);
   Lcd_Display(0x88,data1[2]);
   Lcd_Display(0x98,data1[3]);


	while(1);
}
void FPGA_Init()
{
	CLR=0;
	EN=0;
	PL=1;
	SDAT=1;
	SCK=0;

}

void Lcd_Display(unsigned char addr,unsigned long dat)
{	
	unsigned char number[10]={2};
	unsigned char i=0;
	number[0]=dat/1000000000;
	number[1]=dat%1000000000/100000000;
	number[2]=dat%100000000/10000000;
	number[3]=dat%10000000/1000000;
	number[4]=dat%1000000/100000;
	number[5]=dat%100000/10000;
	number[6]=dat%10000/1000;
	number[7]=dat%1000/100;
	number[8]=dat%100/10;
	number[9]=dat%10;
	write(0,addr);
	for(i=0;i<10;i++)
		write(1,'0'+number[i]);
}
void delay1s20us(void)   //��� -0.46875000024us
{
    unsigned char a,b,c;
    for(c=77;c>0;c--)
        for(b=62;b>0;b--)
            for(a=95;a>0;a--);
}
void read_hc165(void)
{
	unsigned char i,j;
	unsigned long buff[4]={0};
	PL=0;  //����������
	PL=1;
   for(i=0;i<4;i++)
	{
  		for(j=0;j<32;j++)
		{
			buff[i]=buff[i]<<1;
			if(SDAT==1)
		        buff[i]++;
			SCK=1;	 //ʱ����λ
			i+=0;
			SCK=0;
		}
		
	}
	for(i=0;i<4;i++)
		data1[i]=buff[i];
}


