#include<reg52.h>//11.0952M

void 