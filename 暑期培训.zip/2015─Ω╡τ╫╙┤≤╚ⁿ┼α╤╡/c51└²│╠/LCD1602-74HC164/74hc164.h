
extern void send_data(unsigned char dat);

extern void hc164_init();