
extern unsigned char key;

extern unsigned char read_hc165(void);

